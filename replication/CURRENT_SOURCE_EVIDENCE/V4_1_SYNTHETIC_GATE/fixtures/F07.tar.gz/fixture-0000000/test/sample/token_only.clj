(ns sample.token-only (:require [clojure.test :as t]))
(defn helper [] true)