(ns sample.core-test (:require [clojure.test :refer [deftest]]))
(deftest works (is true))