(ns clojure.test)
(defmacro deftest [name & body] nil)